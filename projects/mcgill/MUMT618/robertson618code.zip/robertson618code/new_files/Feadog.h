#ifndef STK_FEADOG_H
#define STK_FEADOG_H

#include "Instrmnt.h"
#include "DelayL.h"
#include "ReedTable.h"
#include "OneZero.h"
#include "PoleZero.h"
#include "Envelope.h"
#include "Noise.h"
#include "SineWave.h"

namespace stk {

/***************************************************/
/*! \class Feadog
    \brief STK penny-whistle physical model class
      with 6 toneholes.

    Hannah Robertson, 2012

    Based on the stk class BlowHole
    by Perry R. Cook and Gary P. Scavone, 1995-2011.
                  *************
    Control Change Numbers:
       - Finger speed = 2
       - Noise Gain = 4
       - Tonehole State = 11
       - Breath Pressure = 128
*/
/***************************************************/

const int HOLE_COUNT = 6; //Number of holes in instrument (no fewer than 6!)

class Feadog : public Instrmnt
{
 public:
  //! Class constructor.
  /*!
    An StkError will be thrown if the rawwave path is incorrectly set.
  */
  Feadog( StkFloat whistleType );

  //! Class constructor with additional argument for setting hole locations
  Feadog( StkFloat whistleType, StkFloat whistleArgs[7]);

  //! Class destructor.
  ~Feadog( void );

  //! Reset and clear all internal state.
  void clear( void );

  //! Create the instrument itself
  void makeWhistle( StkFloat whistleArgs[] );

  //! Sets instrument hole states to play a particular frequency (MIDI # okay too!)
  void setFrequency( StkFloat frequency );

  //! Set state of each hole as open or close
  void setFingering( int midiNote );

  //! Check state of all holes to see if they've reached their specified open/close state
  void checkToneholes( void );

  //! Set speed at which fingers open/close holes
  void setFingerSpeed( void  );

  //! Make sure input note is in midi number range
  void getAndFingerNote( StkFloat frequency_or_midi );

  //! Set the tonehole state for a particular hole(0.0 = closed, 1.0 = fully open).
  void setTonehole( StkFloat newValue, int hole );

  //! Apply breath pressure to instrument with given amplitude and rate of increase.
  void startBlowing( StkFloat amplitude, StkFloat rate );

  //! Decrease breath pressure with given rate of decrease.
  void stopBlowing( StkFloat rate );

  //! Start a note with the given frequency and amplitude.
  void noteOn( StkFloat frequency, StkFloat amplitude );

  //! Stop a note with the given amplitude (speed of decay).
  void noteOff( StkFloat amplitude );

  //! Perform the control change specified by \e number and \e value (0.0 - 128.0).
  void controlChange( int number, StkFloat value );

  //! Compute and return one output sample.
  StkFloat tick( unsigned int channel = 0 );

  //! Fill a channel of the StkFrames object with computed outputs.
  /*!
    The \c channel argument must be less than the number of
    channels in the StkFrames argument (the first channel is specified
    by 0).  However, range checking is only performed if _STK_DEBUG_
    is defined during compilation, in which case an out-of-range value
    will trigger an StkError exception.
  */
  StkFrames& tick( StkFrames& frames, unsigned int channel = 0 );


 protected:
  //Specific to type of whistle created:
  int       whistleType_;   // 1 is low D, default is pennywhistle

  // Whistle body basics
  DelayL    delays_[HOLE_COUNT + 1];  // Segments in pipe (delay lines)
  OneZero   filter_;                  // End reflectance
  StkFloat  nDelay_;                  // Maximum delays of instrument
  StkFloat  freqs_[HOLE_COUNT + 1];   // Ratio distance between each hole on body

  PoleZero  tonehole_[HOLE_COUNT];    // Toneholes (6 in pipe body)
  StkFloat  scatter_[HOLE_COUNT];     // Three-port scattering coefficients, 1 per tonehole
  StkFloat  thCoeff_[HOLE_COUNT];     // Keeps track of filter coefficient for each hole

  // To do with breathing/blowing (unchanged from stk::BlowHole):
  ReedTable reedTable_;
  Envelope  envelope_;
  Noise     noise_;
  SineWave  vibrato_;
  StkFloat  outputGain_;
  StkFloat  noiseGain_;
  StkFloat  vibratoGain_;

  // To do with fingers, tonehole states:
  StkFloat  fingerSpeed_;                   // Seconds it takes to open/close tonehole
  Envelope  fingerEnvelopes_[HOLE_COUNT];   // Current state of hole between open/shut
  bool      updateFingers_[HOLE_COUNT];     // "Need to adjust tonehole(s) openness based on new note?"
  bool      updatetemp;
  int       lowestClosedHole_;              // Keeps track of lowest closed hole (for future ornamentation use)

};

//Main tick function
inline StkFloat Feadog :: tick( unsigned int )
{
  //*UPDATE TONEHOLE STATES*//
  // Check and update toneholes if not at target open/shutness be
  updatetemp = 0;
  for (int i = 0; i < HOLE_COUNT; i++ ){
      if ( updateFingers_[i] == 1 ){          // 1 means 'not at target'
        setTonehole( fingerEnvelopes_[i].tick(), i);
        updatetemp = 1;
      }
  }
  if ( updatetemp )
    checkToneholes();


  //*PLAYER AIR INPUT*//
  StkFloat pressureDiff;
  StkFloat breathPressure;

  // Calculate the breath pressure (envelope + noise + vibrato)
  breathPressure = envelope_.tick();
  breathPressure += breathPressure * noiseGain_ * noise_.tick();
  breathPressure += breathPressure * vibratoGain_ * vibrato_.tick();

  // Calculate the differential pressure = reflected - mouthpiece pressures
  pressureDiff = delays_[0].lastOut() - breathPressure;


  //* DELAYLINE UPDATING *//
  // Scattering junction variables
  StkFloat pa;    // Input values from (+) direction
  StkFloat pb;    // Input values from (-) direction
  StkFloat pth;   // Last output of current tonehole
  StkFloat temp;  // Scattering junction combo of various input values, scaled

  //Initial (player) input into system
  pa = breathPressure + pressureDiff * reedTable_.tick( pressureDiff );

  //Calculate updated delayline values
  for (int i = 0; i < HOLE_COUNT; i++)
  {
    //Collect current state of each hole
    pb = delays_[i+1].lastOut();
    pth = tonehole_[i].lastOut();
    temp = scatter_[i] * (pa + pb - 2 * pth);

    //Input into tonehole
    tonehole_[i].tick( pa + pb - pth + temp );

    //Input into (-) direction delayline
    delays_[i].tick( pb + temp );

    //Input for the next tonehole filter
    pa += temp;
  }

  //* END REFLECTION FILTER *//
  // Result of end filter gets sent through the last delayline
  delays_[HOLE_COUNT].tick( filter_.tick( pa ) * -0.95 );

  //* PRESSURE OUTPUT *//
  //Take as output the last tick of the first delayline
  lastFrame_[0] = delays_[0].lastOut();
  lastFrame_[0] *= outputGain_;
  return lastFrame_[0];
}

//Un-changed from stk::BlowHole -- allows ticks for multiple channels
inline StkFrames& Feadog :: tick( StkFrames& frames, unsigned int channel )
{
  unsigned int nChannels = lastFrame_.channels();
#if defined(_STK_DEBUG_)
  if ( channel > frames.channels() - nChannels ) {
    oStream_ << "Feadog::tick(): channel and StkFrames arguments are incompatible!";
    handleError( StkError::FUNCTION_ARGUMENT );
  }
#endif

  StkFloat *samples = &frames[channel];
  unsigned int j, hop = frames.channels() - nChannels;
  if ( nChannels == 1 ) {
    for ( unsigned int i=0; i<frames.frames(); i++, samples += hop )
      *samples++ = tick();
  }
  else {
    for ( unsigned int i=0; i<frames.frames(); i++, samples += hop ) {
      *samples++ = tick();
      for ( j=1; j<nChannels; j++ )
        *samples++ = lastFrame_[j];
    }
  }

  return frames;
}

} // stk namespace

#endif
