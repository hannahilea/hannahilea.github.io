// test_whistle.cpp
//
// Play with the Feadog (whistle) instrument!
//
// by Hannah Robertson, McGill University, 2012.
//
//compile with:
//g++ -D__MACOSX_CORE__ -L/Developer/stk-4.4.3/src -I/Developer/stk-4.4.3/include/ play_whistle.cpp -o play_whistle -lstk -lpthread -framework CoreAudio -framework CoreMIDI -framework CoreFoundation

#include "Feadog.h"
#include "RtAudio.h"
#include "Messager.h"
#include "SKINI.msg"
#include <math.h>
#include <algorithm>
using std::min;

using namespace stk;

StkFloat whistle_type;
StkFloat myfreqargv[7];
bool holeFlag;
const char * skini_file;

void usage( char *prog ) {
  // Error function in case of incorrect command-line
  // argument specifications.
  std::cout << "\n  useage: " << prog << " file [-w <type>] [-h <#> <#> <#> <#> <#> <#>]\n\n";
  std::cout << "  where   file   = a SKINI scorefile,\n";
  std::cout << "          type   = integer whistle size type (1 = low D, 0 = high D),\n";
  std::cout << "          #      = a list of 6 hole spacing decimals (must sum to < 1).\n\n";
  std::cout << "  Sample usage:\n";
  std::cout << "    " << prog << " scores/slow_demo.ski -w 2 -h .427 .0481 .0667 .0755 .0356 .0808\n\n";

  exit(0);
}

void argumentParse( int argc, char *argv[] )
{
  whistle_type = 0;
  holeFlag = 0;
  try{
    // Make sure there are enough arguments
    if (argc < 2 )
      throw "Not enough arguments!";

    // Set the input score file (if invalid, will be caught later)
    skini_file = argv[1];

    // If no flags, fine -- carry on!
    if (argc == 2)
      return;

    // If argument -w is thrown
    if (argc == 4 || argc == 11)
    {
      if (strncmp( argv[2], "-w", 2) == 0)
        whistle_type = atof( argv[3] );
      else
        std::cout << "Don't understand "<< argv[2] << "; ignoring it.\n";
    }

    // If argument h is thrown
    if (argc == 9 || argc == 11)
    {

      int i;
      if (argc == 9)
        i = 3;
      else
        i = 5;

      //Check user-input hole spacing (6 holes).
      StkFloat remainder = 1;
      while (i < argc)
        {remainder-= atof(argv[i]); i++;}

      //If the spacing is "legal" (fractions add up to 1), overwrite hole spacing
      if (remainder > 0)
      {
        if (argc == 9)
          i = 3;
        else
          i = 5;
        for (int j = 0; j<6; j++)
          myfreqargv[j] = atof(argv[j+i]);
        myfreqargv[6] = remainder;
        holeFlag = 1;

      }
      //Otherwise, leave it!
      else
        std::cout << "Trying to place holes off whistle body! Ignoring this flag.\n";
    }

    else if (argc!= 2 && argc != 4 && argc != 9 && argc != 11)
    {
      throw "Wrong number of args; check spaces in usage!\n";
    }
  }
  catch(char *str){
    std::cout << "Exception raised: " << str << "\n";
    std::cout << "only " << argc << " args used!\n";
    usage( argv[0] );
  }
}

// The TickData structure holds all the class instances and data that
// are shared by the various processing functions.
struct TickData {
  Instrmnt *instrument;
  Messager messager;
  Skini::Message message;
  int counter;
  bool haveMessage;
  bool done;

  // Default constructor.
  TickData()
    : instrument(0), counter(0), haveMessage(false), done( false ) {}
};

#define DELTA_CONTROL_TICKS 64 // default sample frames between control input checks

// The processMessage() function encapsulates the handling of control
// messages.
// Because messages are already handled within the Feadog class, just pass
// the straight through.
void processMessage( TickData* data )
{
  register StkFloat value1 = data->message.floatValues[0];
  register StkFloat value2 = data->message.floatValues[1];

  switch( data->message.type ) {

  case __SK_Exit_:
    data->done = true;
    return;

  case __SK_NoteOn_:
    if ( value2 == 0.0 ) // velocity is zero ... really a NoteOff
      data->instrument->noteOff( 0.5 );
    else { // a NoteOn -- Feadog can accept midi or frequency, midi easier here
      StkFloat frequency = value1;
      data->instrument->noteOn( frequency, value2 * ONE_OVER_128 );
    }
    break;

  case __SK_NoteOff_:
    data->instrument->noteOff( value2 * ONE_OVER_128 );
    break;

  default:
    data->instrument->controlChange( (int) value1, value2 );
    break;

  } // end of switch

  data->haveMessage = false;
  return;
}

// This tick() function handles sample computation and scheduling of
// control updates.  It will be called automatically when the system
// needs a new buffer of audio samples.
int tick( void *outputBuffer, void *inputBuffer, unsigned int nBufferFrames,
         double streamTime, RtAudioStreamStatus status, void *dataPointer )
{
  TickData *data = (TickData *) dataPointer;
  register StkFloat *samples = (StkFloat *) outputBuffer;
  int counter, nTicks = (int) nBufferFrames;

  while ( nTicks > 0 && !data->done ) {

    if ( !data->haveMessage ) {
      data->messager.popMessage( data->message );
      if ( data->message.type > 0 ) {
        data->counter = (long) (data->message.time * Stk::sampleRate());
        data->haveMessage = true;
      }
      else
        data->counter = DELTA_CONTROL_TICKS;
    }

    counter = min( nTicks, data->counter );
    data->counter -= counter;

    for ( int i=0; i<counter; i++ ) {
      *samples++ = data->instrument->tick();
      nTicks--;
    }
    if ( nTicks == 0 ) break;

    // Process control messages.
    if ( data->haveMessage ) processMessage( data );
  }

  return 0;
}

int main( int argc, char *argv[] )
{
  argumentParse( argc, argv );

  // Set the global sample rate and rawwave path before creating class instances.
  Stk::setSampleRate( 44100.0 );

  Stk::setRawwavePath( "../../rawwaves/" );

  TickData data;
  RtAudio dac;

  // Figure out how many bytes in an StkFloat and setup the RtAudio stream.
  RtAudio::StreamParameters parameters;
  parameters.deviceId = dac.getDefaultOutputDevice();
  parameters.nChannels = 1;
  RtAudioFormat format = ( sizeof(StkFloat) == 8 ) ? RTAUDIO_FLOAT64 : RTAUDIO_FLOAT32;
  unsigned int bufferFrames = RT_BUFFER_SIZE;
  try {
    dac.openStream( &parameters, NULL, format, (unsigned int)Stk::sampleRate(), &bufferFrames, &tick, (void *)&data );
  }
  catch ( RtError &error ) {
    error.printMessage();
    goto cleanup;
  }

  try {
    // Define and load the Feadog (whistle) instrument
    if (holeFlag == 1)
    {
      data.instrument = new Feadog( whistle_type, myfreqargv );
    }
    else
      data.instrument = new Feadog( whistle_type );
  }
  catch ( StkError & ) {
    goto cleanup;
  }

  if ( data.messager.setScoreFile( skini_file ) == false )
    goto cleanup;

  try {
    dac.startStream();
  }
  catch ( RtError &error ) {
    error.printMessage();
    goto cleanup;
  }

  // Block waiting until callback signals done.
  while ( !data.done )
    Stk::sleep( 100 );

  // Shut down the output stream.
  try {
    dac.closeStream();
  }
  catch ( RtError &error ) {
    error.printMessage();
  }

 cleanup:
  delete data.instrument;

  return 0;
}