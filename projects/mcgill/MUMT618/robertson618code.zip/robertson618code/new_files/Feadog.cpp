
/***************************************************/
/*! \class Feadog
    \brief STK penny-whistle physical model class
      with 6 toneholes.

    Hannah Robertson, 2012

    Based on the stk class BlowHole
    by Perry R. Cook and Gary P. Scavone, 1995-2011.
                  *************
    Control Change Numbers:
       - Finger speed = 2
       - Noise Gain = 4
       - Tonehole State = 11
       - Breath Pressure = 128
*/
/***************************************************/


#include "Feadog.h"
#include "SKINI.msg"
#include <cmath>

namespace stk {

//Basic constructor
Feadog :: Feadog( StkFloat whistleType )
{
  whistleType_ = floor( whistleType );
  StkFloat i[]={0};
  makeWhistle( i ); //Make whistle with default hole locations
}

//Constructor with non-default hole locations
Feadog :: Feadog( StkFloat whistleType, StkFloat whistleArgs[7])
{
  whistleType_ = floor( whistleType );
  makeWhistle( whistleArgs );
}

//Create a whistle given various whistle attributes
void Feadog :: makeWhistle( StkFloat whistleArgs[] )
{
  StkFloat lowestFrequency;   //Frequency of lowest whistle note
  StkFloat rb;                //main bore radius

  //defult radius for each tonehole
  StkFloat rth[] = {0.0025, 0.0025, 0.0025, 0.0015, 0.00215, 0.0025};

  //Set hole spacing: fraction of total delay line between hole and previous
  //hole: air input <--  45% --> hole0 <-- 7% --> hole1 <--.....-->whistle end
  freqs_[0] = .4583;  //between air input and first hole (hole[0])
  freqs_[1] = .0709;
  freqs_[2] = .0634;
  freqs_[3] = .0370;
  freqs_[4] = .0650;
  freqs_[5] = .1185;
  freqs_[6] = .1870; //between last hole and end of whistle


  //CHANGE VARIABLES BASED ON TYPE OF WHISTLE
  switch( whistleType_ ){
    case 1:
      //Low D whistle
      std::cout << "Building low D whistle (low octave).\n";
      lowestFrequency = 298.75; // .5 * intended frequency to get low octave (currently 'overblown' to hit 2nd octave)
      rb = 0.011;
      //Different hole spacing
      freqs_[0] = .4583;
      freqs_[1] = .0709;
      freqs_[2] = .0634;
      freqs_[3] = .0370;
      freqs_[4] = .0650;
      freqs_[5] = .1185;
      freqs_[6] = .1870;
      //Different hole radius values
      rth[0] = 0.005;
      rth[1] = 0.005;
      rth[2] = 0.005;
      rth[3] = 0.003;
      rth[4] = 0.0045;
      rth[5] = 0.005;
      break;
    case 2:
      //Attempting regular pennywhistle
      std::cout << "Attempting a regular high D pennywhistle, high octave (way out of tune!).\n";
      lowestFrequency = 1174.66; //Hz, D6 (actually gives lowest note an octave up)
      rb = 0.0065;
      break;
    default:
      std::cout << "Building a high whistle\n";
      lowestFrequency = 587.33; // Hz, D5 //Actually tuned for low D whistle but plays higher octave
      rb = 0.011;
      freqs_[0] = .4270;
      freqs_[1] = .0481;
      freqs_[2] = .0667;
      freqs_[3] = .0755;
      freqs_[4] = .0356;
      freqs_[5] = .0808;
      freqs_[6] = .2663;
      //Different hole radius values
      rth[0] = 0.005;
      rth[1] = 0.005;
      rth[2] = 0.005;
      rth[3] = 0.003;
      rth[4] = 0.0045;
      rth[5] = 0.005;
      break;
  }

  //Can't build a whistle with 0 length
  if ( lowestFrequency <= 0.0 ) {
    oStream_ << "Feadog::Feadog: argument is less than or equal to zero!";
    handleError( StkError::FUNCTION_ARGUMENT );
  }

  //If there was a special hole spacing passed to this command, make use of it
  if (whistleArgs[0] != 0)
  {
    std::cout << "Specialty hole spacing!\n";
    for (int i = 0; i < 7 ; i++)
      freqs_[i] = whistleArgs[i];
  }

  //Start building the delaylines!
  unsigned long nDelays = (unsigned long) ( 0.5 * Stk::sampleRate() / lowestFrequency );
  nDelay_ = nDelays;

  //For each segment, set delay
  StkFloat delay;
  for ( int i = 0; i < HOLE_COUNT + 1; i++ ){
    delay = (freqs_[i] * nDelays - 1); //Account for 1 sample lastOut delay (for each tonehole and the end filter)

    //Set each delayline segment
    delays_[i].setMaximumDelay( nDelays + 1 );
    delays_[i].setDelay( delay );
  }

  //Set reed table (unchanged from stk::BlowHole)
  reedTable_.setOffset( 0.7 );
  reedTable_.setSlope( -0.3 );

  //Set fingers:
  fingerSpeed_ = 0.0001;
  setFingerSpeed();

  //For each tonehole...
  StkFloat te;
  for (int i = 0; i < HOLE_COUNT; i++){
    //Calculate the initial three-port scattering constant for the tonehole
    //given the main bore radius and tonehole radius
    scatter_[i] = -pow(rth[i],2) / ( pow(rth[i],2) + 2*pow(rb,2) );

    //Calculate tonehole's filter coefficients and set hole filter as open.
    te = 1.4 * rth[i];    //effective length of the open hole
    thCoeff_[i] = (te*2*Stk::sampleRate() - 347.23) / (te*2*Stk::sampleRate() + 347.23);
    tonehole_[i].setA1( -thCoeff_[i] );
    tonehole_[i].setB0( thCoeff_[i] );
    tonehole_[i].setB1( -1.0 );

    //Set the finger to be initially up (hole open)
    fingerEnvelopes_[i].setValue( 1 ); //Sets current/goal hole state to open

    //Indicate that until note changes, fingers are fine
    updateFingers_[i] = 0;
  }

  //Other preliminary variable initializations (unchanged from stk::BlowHole)
  vibrato_.setFrequency((StkFloat) 5.735);
  outputGain_ = 1.0;
  noiseGain_ = 0.2;
  vibratoGain_ = 0.01;

  setFingering( 73 ); //Set note fingering to all holes open (C#)
  this->clear();
}

Feadog :: ~Feadog( void )
{
}

void Feadog :: clear( void )
{
  filter_.tick( 0.0 );

  for (int i = 0; i <= HOLE_COUNT; i++)
    delays_[i].clear();
  for (int i = 0; i < HOLE_COUNT; i++)
    tonehole_[i].tick( 0.0 );
}

//In this instrument, frequency is set by the fingering
//rather than the length of the tube. This function is a workaround
//so that (setFrequency) can function for Feadog just as it does for any
//other STK instruments in the various demos and examples.
void Feadog :: setFrequency( StkFloat frequency )
{

#if defined(_STK_DEBUG_)
  if ( frequency <= 0.0 ) {
    oStream_ << "Feadog::setFrequency: argument is less than or equal to zero!";
    handleError( StkError::WARNING ); return;
  }
#endif
  int freq_int_MIDI = (int)frequency;
  getAndFingerNote( freq_int_MIDI );
}

//Set fingering for notes! Single octave, includes half-holes.
void Feadog :: setFingering( int midiNote )
{
    /*62 xxxxxx
      64 xxxxx
      66 xxxx
      67 xxx
      69 xx
      71 x
      73*/

  switch ( midiNote )
  {
    case 62: //lowest note (standard D)(midi D4)(all closed)
      std::cout << "Playing D4!\n";
      fingerEnvelopes_[0].setTarget( 0 );
      fingerEnvelopes_[1].setTarget( 0 );
      fingerEnvelopes_[2].setTarget( 0 );
      fingerEnvelopes_[3].setTarget( 0 );
      fingerEnvelopes_[4].setTarget( 0 );
      fingerEnvelopes_[5].setTarget( 0 );
      lowestClosedHole_ = 5;
      break;
    case 63: //(D#/Eb)
      std::cout << "Playing D4# (half-holed).\n";
      fingerEnvelopes_[0].setTarget( 0 );
      fingerEnvelopes_[1].setTarget( 0 );
      fingerEnvelopes_[2].setTarget( 0 );
      fingerEnvelopes_[3].setTarget( 0 );
      fingerEnvelopes_[4].setTarget( 0 );
      fingerEnvelopes_[5].setTarget( .5 );
      lowestClosedHole_ = 5;
      break;
    case 64: //(standard E)
      std::cout << "Playing E!\n";
      fingerEnvelopes_[0].setTarget( 0 );
      fingerEnvelopes_[1].setTarget( 0 );
      fingerEnvelopes_[2].setTarget( 0 );
      fingerEnvelopes_[3].setTarget( 0 );
      fingerEnvelopes_[4].setTarget( 0 );
      fingerEnvelopes_[5].setTarget( 1 );
      lowestClosedHole_ = 4;
      break;
    case 65: //(standard F natural)
      std::cout << "Playing F natural (half-holed)\n";
      fingerEnvelopes_[0].setTarget( 0 );
      fingerEnvelopes_[1].setTarget( 0 );
      fingerEnvelopes_[2].setTarget( 0 );
      fingerEnvelopes_[3].setTarget( 0 );
      fingerEnvelopes_[4].setTarget( .5 );
      fingerEnvelopes_[5].setTarget( 1 );
      lowestClosedHole_ = 4;
      break;
    case 66: //(standard F#)
      std::cout << "Playing F#!\n";
      fingerEnvelopes_[0].setTarget( 0 );
      fingerEnvelopes_[1].setTarget( 0 );
      fingerEnvelopes_[2].setTarget( 0 );
      fingerEnvelopes_[3].setTarget( 0 );
      fingerEnvelopes_[4].setTarget( 1 );
      fingerEnvelopes_[5].setTarget( 1 );
      lowestClosedHole_ = 3;
      break;
    case 67: //(standard G)
      std::cout << "Playing G.\n";
      fingerEnvelopes_[0].setTarget( 0 );
      fingerEnvelopes_[1].setTarget( 0 );
      fingerEnvelopes_[2].setTarget( 0 );
      fingerEnvelopes_[3].setTarget( 1 );
      fingerEnvelopes_[4].setTarget( 1 );
      fingerEnvelopes_[5].setTarget( 1 );
      lowestClosedHole_ = 2;
      break;
    case 68: //(standard G#)
      std::cout << "Playing G# (half-holed).\n";
      fingerEnvelopes_[0].setTarget( 0 );
      fingerEnvelopes_[1].setTarget( 0 );
      fingerEnvelopes_[2].setTarget( .5 );
      fingerEnvelopes_[3].setTarget( 1 );
      fingerEnvelopes_[4].setTarget( 1 );
      fingerEnvelopes_[5].setTarget( 1 );
      lowestClosedHole_ = 2;
      break;
    case 69: //(standard A)
      std::cout << "Playing A.\n";
      fingerEnvelopes_[0].setTarget( 0 );
      fingerEnvelopes_[1].setTarget( 0 );
      fingerEnvelopes_[2].setTarget( 1 );
      fingerEnvelopes_[3].setTarget( 1 );
      fingerEnvelopes_[4].setTarget( 1 );
      fingerEnvelopes_[5].setTarget( 1 );
      lowestClosedHole_ = 1;
      break;
    case 70: //( A#)
      std::cout << "Playing A# (half-holed).\n";
      fingerEnvelopes_[0].setTarget( 0 );
      fingerEnvelopes_[1].setTarget( .5 );
      fingerEnvelopes_[2].setTarget( 1 );
      fingerEnvelopes_[3].setTarget( 1 );
      fingerEnvelopes_[4].setTarget( 1 );
      fingerEnvelopes_[5].setTarget( 1 );
      lowestClosedHole_ = 1;
      break;
    case 71: //(standard B)
      std::cout << "Playing B.\n";
      fingerEnvelopes_[0].setTarget( 0 );
      fingerEnvelopes_[1].setTarget( 1 );
      fingerEnvelopes_[2].setTarget( 1 );
      fingerEnvelopes_[3].setTarget( 1 );
      fingerEnvelopes_[4].setTarget( 1 );
      fingerEnvelopes_[5].setTarget( 1 );
      lowestClosedHole_ = 0;
      break;
    case 72: //(C natural)
      std::cout << "Playing C natural (half-holed).\n";
      fingerEnvelopes_[0].setTarget( 1 );
      fingerEnvelopes_[1].setTarget( 0 );
      fingerEnvelopes_[2].setTarget( 0 );
      fingerEnvelopes_[3].setTarget( 1 );
      fingerEnvelopes_[4].setTarget( 1 );
      fingerEnvelopes_[5].setTarget( 1 );
      lowestClosedHole_ = 0;
      break;
    case 11: //(alternate C natural)
      std::cout << "Playing other C natural (half-holed).\n";
      fingerEnvelopes_[0].setTarget( .5 );
      fingerEnvelopes_[1].setTarget( 1 );
      fingerEnvelopes_[2].setTarget( 1 );
      fingerEnvelopes_[3].setTarget( 1 );
      fingerEnvelopes_[4].setTarget( 1 );
      fingerEnvelopes_[5].setTarget( 1 );
      lowestClosedHole_ = 0;
      break;
    default: //73 (c# -- all open)
      std::cout << "Playing C# (also default).\n";
      fingerEnvelopes_[0].setTarget( 1 );
      fingerEnvelopes_[1].setTarget( 1 );
      fingerEnvelopes_[2].setTarget( 1 );
      fingerEnvelopes_[3].setTarget( 1 );
      fingerEnvelopes_[4].setTarget( 1 );
      fingerEnvelopes_[5].setTarget( 1 );
      lowestClosedHole_ = 0;
  }
  checkToneholes();
}

//Check to see if toneholes are fully shut/open in line with their target state
//(which is set by playing a note)
void Feadog :: checkToneholes( void )
{
  //Check each tonehole individually
  for (int i = 0; i < HOLE_COUNT; i++ ){
    updateFingers_[i] = fingerEnvelopes_[i].getState(); //state is 0 at target, 1 otherwise
  }
}

//Set speed at which holes open/shut
void Feadog :: setFingerSpeed( void )
{
  for (int i = 0; i < HOLE_COUNT; i++ ){
    fingerEnvelopes_[i].setTime( fingerSpeed_ ); //.001 seconds
  }
}

//Take both frequency and MIDI note inputs and convert to MIDI number, send to
//setFingering function to actually get played
void Feadog :: getAndFingerNote( StkFloat frequency_or_midi )
{
  int note;
  //If the note played in is in Hz...
  if (frequency_or_midi > 100){
    //Convert freq back to MIDI pitch
    note = 69 + round( 12.0 * log( frequency_or_midi / 440.0 ) / log( 2.0 ));
  }
  else //make sure it's an integer
    {
      note = floor( frequency_or_midi );
    }

  setFingering( note ); //Send the MIDI note value; values outside the
                        //instrument range will be given non-corresponding midi values
}

//Set the tonehole "open-ness" of any specific hole to
//any point between "Open" (newValue = 1) and "Closed"
//(newValue = 0).
void Feadog :: setTonehole( StkFloat newValue, int hole )
{
   //Check hole; if not a legal one, then don't do anything
#if defined(_STK_DEBUG_)
  if (hole >= HOLE_COUNT || hole < 0) {
    oStream_ << "Feadog::tonehole error: hole (" << value << ") doesn't exist on this instrument!";
    handleError( StkError::WARNING ); return;
  }
#endif

  StkFloat new_coeff;

  if ( newValue <= 0.0 )
    new_coeff = 0.9995;
  else if ( newValue >= 1.0 )
    new_coeff = thCoeff_[hole];
  else
    new_coeff = ( newValue * (thCoeff_[hole] - 0.9995) ) + 0.9995;

  //Set the hole to its new number
  tonehole_[hole].setA1( -new_coeff );
  tonehole_[hole].setB0( new_coeff );

}

//Unchanged from stk::BlowHole
void Feadog :: startBlowing( StkFloat amplitude, StkFloat rate )
{
  if ( amplitude <= 0.0 || rate <= 0.0 ) {
    oStream_ << "Feadog::startBlowing: one or more arguments is less than or equal to zero!";
    handleError( StkError::WARNING ); return;
  }

  envelope_.setRate( rate );
  envelope_.setTarget( amplitude );
}

//Unchanged from stk::BlowHole
void Feadog :: stopBlowing( StkFloat rate )
{
  if ( rate <= 0.0 ) {
    oStream_ << "Feadog::stopBlowing: argument is less than or equal to zero!";
    handleError( StkError::WARNING ); return;
  }

  envelope_.setRate( rate );
  envelope_.setTarget( 0.0 );
}

//Unchanged from stk::BlowHole
void Feadog :: noteOn( StkFloat frequency, StkFloat amplitude )
{
  int freq_int_MIDI = (int)frequency;
  getAndFingerNote( freq_int_MIDI );

  this->startBlowing( 0.55 + (amplitude * 0.30), amplitude * 0.005 );
  outputGain_ = amplitude + 0.001;
}

//Unchanged from stk::BlowHole
void Feadog :: noteOff( StkFloat amplitude )
{
  this->stopBlowing( amplitude * 0.01 );
}

//SKINI/MIDI controls
void Feadog :: controlChange( int number, StkFloat value )
{
#if defined(_STK_DEBUG_)
  if ( Stk::inRange( value, 0.0, 128.0 ) == false ) {
    oStream_ << "Feadog::controlChange: value (" << value << ") is out of range!";
    handleError( StkError::WARNING ); return;
  }
#endif

  StkFloat normalizedValue = value * ONE_OVER_128;

  //Change the fingering speed (has nothing to do with reed stiffness!)
  if (number == __SK_ReedStiffness_) //2
  {
    fingerSpeed_ = .0001 + normalizedValue;
    setFingerSpeed();
    std::cout << "Just changed finger speed to " << fingerSpeed_ << "\n";
  }
  //Change noise level (unchanged from stk::BlowHole)
  else if (number == __SK_NoiseLevel_) //4
    noiseGain_ = ( normalizedValue * 0.4);
  //Change openness of lowest hole closed
  else if (number == __SK_ModFrequency_) //11
  {
    //"set openness of the lowest hole that is closed"
    //std::cout << "Just changed hole " << lowestClosedHole_ << " to " << normalizedValue << ".\n";
    this->setTonehole( normalizedValue, lowestClosedHole_ );
    this->checkToneholes();
  }
  //Change whistle type to a different preset
  else if (number == __SK_ModWheel_) //1
  {
    //"set whistle type"
    std::cout << "Just changed whistle to kind " << value << ".\n";
    whistleType_ = floor( value );
    this->clear();
    StkFloat i[]={0};
    this->makeWhistle( i );
  }
  else if (number == __SK_AfterTouch_Cont_) //128
    envelope_.setValue( normalizedValue );

#if defined(_STK_DEBUG_)
  else {
    oStream_ << "Feadog::controlChange: undefined control number (" << number << ")!";
    handleError( StkError::WARNING );
  }
#endif
}

} //stk namespace
