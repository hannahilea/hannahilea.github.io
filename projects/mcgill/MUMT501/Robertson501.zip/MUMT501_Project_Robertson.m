%% Hannah / Robertson / Final Project: Onset Detection of Ornamentation

% input a file (shorten it for procesing ease!)
 [x, fs] = wavread('xmas.wav'); %"Christmas Eve," a traditional tune, as played by Grey Larson
 x = x(:,1); %make mono (the two tracks were duplicates to begin with)
 x = x(1+5000:fs*2+5000); %shorten to 2 sec sample, starting just before the song starts
 
% Set variables:
% distance (in samples) between consecutive frames
hop = 512;

% size of each frame to be analyzed
frame = 1024;

% trim down song length to a multiple of frame size (ease of demo)
a = floor(length(x)/frame);
x = x(1:a*frame);

% number of frames to be analyzed 
numhops = (length(x)/hop) - 1;

% a hanning window (as used in both papers) the length of the frame
h = hann(frame);

%% Look for the peaks in the original to determine what the fundamental
% note frequencies are going to be (Not an important step for the
% algorithm! this is essentially 'tuning' the program to the instrument)

%figure
k= 2*pi*(1:length(x))*fs/1000000;
X = abs(fft(x));

%from plot, choose peaks
plot(k(1:3500),X(1:3500));

% What are the frequencies we are particularly interested in? Chosen from
% peaks in plot
f0s = [330 370.2 442.2 493.5 556.4 610.4 660.9];

display('initialized');

%% Define the comb filters for each filter in the bank:
% H(z) = fgain(1 + freqgain*z^{-M})
% feedforward b/c FIR, doesn't depend on past values
% note: "-" in "-M" is implicit in filter command, fgain is positive
% (although was negative in class)

clear fbank;
if ~exist('Fs','var') 
    Fs = 44100; 
end

for ii = 1:length(f0s)
    
    f0 = f0s(ii);
    
    % Scaling factor, to be applied to the whole output signal
    fgain = 1;  

    % Sets constructive interference at multiples of 2pi starting at 0 
    % rather than pi
    freqgain = 1; 

    % sets the delay (in number of samples); this sets the
    % width of the comb 'tines'. Here we want it to be spaced at
    % frequency f_0, which happens at sample imcrement Fs/f_0
    M = round(Fs/f0); 

    %Filter denominator, just 1 because there are no feedback components
    % (otherwise there'd by z-dpendent components)
    a = 1;

    % Filter numerator:
    %Note: a vector of polynomial coeff's, all but the first and last are 0
    %set number of terms in polynomial to number of samples in the delay M
    b = zeros(M,1);
    %want the first term in the numerator's polynomial vector to be 1*b0
    b(1) = fgain*1;
    %want the last (highest power) term in the numerator's polynomial vector to be b0*beta
    b(end) = fgain*freqgain;
    
    %Add filter to filter bank: f0 is frequency, a is denom, b is num,
    thisfilter = {f0 a b};
    if exist('fbank', 'var')
        fbank = cat(1, fbank, thisfilter);
    else
        fbank = thisfilter; %%If it doesn't exist yet, create it
    end
end

disp('filter bank created.');

%% Okay, let's process sound!

%running each frame through a bank of comb filters (1 for each note).

spectralFits = zeros(length(fbank(:,1)),numhops);
energies = zeros(length(fbank(:,1)),numhops);

%For each filter in the filterbank...

for ii = 1:length(fbank(:,1))
    display(['ok...starting filter ' num2str(ii) ' of ' num2str(length(f0s))]);

    %For each hopped frame in the piece:
    for jj = 1:numhops
        
        %pull out this section of the song
        xstart = ((jj - 1) * hop) + 1;
        xstop = xstart + frame - 1;
        xthis = x(xstart:xstop);
        
        %apply the hanning window to this frame
        xthis = xthis.*h;
    
        %(2) taking the STFT of frame, and then 
        %Take the STFT of the frame
        X = fft(xthis);
        
        %Figure out the frame's initial energy
        Emax = sum(X.^2);
        
        %Run the frame through the filter
        b=fbank{ii,3,:};
        a=fbank{ii,2,:};
        y = filter(b,a,xthis);
        
        %Figure out the frame's final energy
        Y = fft(y);
        E = sum(Y.^2);
        
        %normalize the energy by dividing by 4*old energy
        E = E./(4*Emax);
        
        %get spectral fit: take abs of normalized energy - 1        
        %Add spectral fit to spectral fit of entire piece
        fit = abs(E-1);
        
        spectralFits(ii,jj) = fit;
        energies(ii,jj) = Emax;
    end
end
display('done filtering');

%For each comb filtered+frame combo,  (a) measured the energy, (b) normalized the energy by dividing by 4*frame?s original energy, 
%(c) calculate the spectral fit by taking the absolute value of the normalized energy -1. 
%To get the ODF, (4) for each frame, sum the square of the spectral fit for a frame minus the spectral fit of the next frame over all comb filters. 
%This will give a value between 0 and 1 that will key an onset.


%% ODF
% for each filter, at each sample take the square of the energy minus the
% energy of the next frame


%For each filter in the filterbank...
ODFs = zeros(length(fbank(:,1)), numhops);
figure;

for ii = 1:length(fbank(:,1))
    %Get vector of spectral fits
    sfit = spectralFits(ii,:);
    
    for jj = 1:numhops
        %Calculate the difference in energies from the last
        %sample
        if jj==1
            ODFs(ii,jj) = (sfit(jj));
        else
            ODFs(ii,jj) = ii*(sfit(jj) - sfit(jj-1));
        end
    end
    subplot(4,2,ii);
    plot(1:numhops, ODFs(ii,:));
    title(['ODF for filter ' num2str(ii) ' with f0 = ' num2str(f0s(ii)) ' Hz']);
    set(gca,'xgrid','on','xtick',[0:25:200],'ytick',[]);
end
    subplot(4,2,ii);
    xlabel('Frame number');
    ylabel('Onset strength (arbitrary)');

%%
%full detection function: take the odf of each filter, sum them
ODFfull = sum(ODFs.^2);

%let's plot!
figure;

%time values for original file
t = (1:length(x))/Fs;

subplot(2,1,1);
%plot the original sound file
plot(t,x);
title('Original sound tile in the time domain');
xlabel('Time (sec)');
ylabel('Normalized Amplitude');
set(gca,'xgrid','on','xtick',[0:.1:2]);

subplot(2,1,2);
plot(1:numhops,ODFfull);
title('Full ODF - time-aligned to original sound file');
xlabel('Frame number');
ylabel('Onset strength (arbitrary)');
set(gca,'xgrid','on','xtick',[0:10:200], 'yscale','log');



