// test_fipple.cpp
//
// Play SKINI scores with the Feadog (whistle) instrument, with the ability to
// adjust various fipple parameters.
//
// by Hannah Robertson, McGill University, 2012.
//
//compile with:
//g++ -D__MACOSX_CORE__ -L/Developer/stk-4.4.3/src -I/Developer/stk-4.4.3/include/ test_fipple.cpp -o test_fipple -lstk -lpthread -framework CoreAudio -framework CoreMIDI -framework CoreFoundation

#include "Feadog.h"
#include "RtAudio.h"
#include "Messager.h"
#include "SKINI.msg"
#include <math.h>
#include <algorithm>
using std::min;

using namespace stk;

StkFloat whistle_type;
bool reedFlag;
bool bodyFlag;
const char * skini_file;

void usage( char *prog ) {
  // Error function in case of incorrect command-line
  // argument specifications.
  std::cout << "\n  useage: " << prog << " file [-w <type>] [-r] [-b]\n\n";
  std::cout << "  where   file   = a SKINI scorefile,\n";
  std::cout << "          type   = integer whistle size type (1 = low D, 0 = high D),\n";
  std::cout << "          -r     = indicates using reedtable excitation source.\n\n";
  std::cout << "          -b     = indicates using simple cylindrical body.\n\n";
  std::cout << "  Sample usage:\n";
  std::cout << "    " << prog << " scores/slow_demo.ski -w 2\n\n";

  exit(0);
}

void argumentParse( int argc, char *argv[] )
{
  whistle_type = 0;
  reedFlag = 0;
  bodyFlag = 0;

  try{
    // Make sure there are enough arguments
    if (argc < 2 )
      throw "Not enough arguments!";

    // Set the input score file (if invalid, will be caught later)
    skini_file = argv[1];

    // If no flags, fine -- carry on!
    if (argc == 2)
      return;

    // If argument -w is thrown
    if (argc == 4 || argc == 5 || argc == 6)
    {
      if (strncmp( argv[2], "-w", 2) == 0)
        whistle_type = atof( argv[3] );
      else
        std::cout << "Don't understand "<< argv[2] << "; ignoring it.\n";
    }

    // If argument -r or -b is thrown, set flag
    if (argc > 2)
    {
      for (int i=2; i<argc; i++)
      {
        if (strncmp( argv[i], "-r", 2) == 0)
          reedFlag = 1;
        if (strncmp( argv[i], "-b", 2) == 0)
          bodyFlag = 1;
      }
    }

    if (argc < 2 || argc > 6)
    {
      throw "Wrong number of args; check spaces in usage!\n";
    }

    //std::cout << "Reed: " << reedFlag << " Body: " << bodyFlag << "\n";
  }
  catch(char *str){
    std::cout << "Exception raised: " << str << "\n";
    std::cout << "only " << argc << " args used!\n";
    usage( argv[0] );
  }
}

// The TickData structure holds all the class instances and data that
// are shared by the various processing functions.
struct TickData {
  Instrmnt *instrument;
  Messager messager;
  Skini::Message message;
  int counter;
  bool haveMessage;
  bool done;

  // Default constructor.
  TickData()
    : instrument(0), counter(0), haveMessage(false), done( false ) {}
};

#define DELTA_CONTROL_TICKS 64 // default sample frames between control input checks

// The processMessage() function encapsulates the handling of control
// messages.
// Because messages are already handled within the Feadog class, just pass
// the straight through.
void processMessage( TickData* data )
{
  register StkFloat value1 = data->message.floatValues[0];
  register StkFloat value2 = data->message.floatValues[1];

  switch( data->message.type ) {

  case __SK_Exit_:
    data->done = true;
    return;

  case __SK_NoteOn_:
    if ( value2 == 0.0 ) // velocity is zero ... really a NoteOff
      data->instrument->noteOff( 0.5 );
    else { // a NoteOn -- Feadog can accept midi or frequency, midi easier here
      StkFloat frequency = value1;
      data->instrument->noteOn( frequency, value2 * ONE_OVER_128 );
    }
    break;

  case __SK_NoteOff_:
    data->instrument->noteOff( value2 * ONE_OVER_128 );
    break;

  default:
    data->instrument->controlChange( (int) value1, value2 );
    break;

  } // end of switch

  data->haveMessage = false;
  return;
}

// This tick() function handles sample computation and scheduling of
// control updates.  It will be called automatically when the system
// needs a new buffer of audio samples.
int tick( void *outputBuffer, void *inputBuffer, unsigned int nBufferFrames,
         double streamTime, RtAudioStreamStatus status, void *dataPointer )
{
  TickData *data = (TickData *) dataPointer;
  register StkFloat *samples = (StkFloat *) outputBuffer;
  int counter, nTicks = (int) nBufferFrames;

  while ( nTicks > 0 && !data->done ) {

    if ( !data->haveMessage ) {
      data->messager.popMessage( data->message );
      if ( data->message.type > 0 ) {
        data->counter = (long) (data->message.time * Stk::sampleRate());
        data->haveMessage = true;
      }
      else
        data->counter = DELTA_CONTROL_TICKS;
    }

    counter = min( nTicks, data->counter );
    data->counter -= counter;

    for ( int i=0; i<counter; i++ ) {
      *samples++ = data->instrument->tick();
      nTicks--;
    }
    if ( nTicks == 0 ) break;

    // Process control messages.
    if ( data->haveMessage ) processMessage( data );
  }

  return 0;
}

int main( int argc, char *argv[] )
{
  argumentParse( argc, argv );

  // Set the global sample rate and rawwave path before creating class instances.
  Stk::setSampleRate( 44100.0 );

  Stk::setRawwavePath( "../../rawwaves/" );

  TickData data;
  RtAudio dac;

  // Figure out how many bytes in an StkFloat and setup the RtAudio stream.
  RtAudio::StreamParameters parameters;
  parameters.deviceId = dac.getDefaultOutputDevice();
  parameters.nChannels = 1;
  RtAudioFormat format = ( sizeof(StkFloat) == 8 ) ? RTAUDIO_FLOAT64 : RTAUDIO_FLOAT32;
  unsigned int bufferFrames = RT_BUFFER_SIZE;
  try {
    dac.openStream( &parameters, NULL, format, (unsigned int)Stk::sampleRate(), &bufferFrames, &tick, (void *)&data );
  }
  catch ( RtError &error ) {
    error.printMessage();
    goto cleanup;
  }

  try {
    // Define and load the Feadog (whistle) instrument
    if (reedFlag == 1 || bodyFlag == 1)
    {
      //Set the type of inst: 999-just reed; 998-both; 997-just body
      StkFloat temp= 998;
      if (reedFlag == 1 && bodyFlag == 0)
        temp = 999; // just reed
      else if (reedFlag == 0 && bodyFlag == 1)
        temp = 997; // just body
      StkFloat  rClue[7] = { temp };
      data.instrument = new Feadog( whistle_type, rClue );
    }
    else
      data.instrument = new Feadog( whistle_type );
  }
  catch ( StkError & ) {
    goto cleanup;
  }

  if ( data.messager.setScoreFile( skini_file ) == false )
    goto cleanup;

  try {
    dac.startStream();
  }
  catch ( RtError &error ) {
    error.printMessage();
    goto cleanup;
  }

  // Block waiting until callback signals done.
  while ( !data.done )
    Stk::sleep( 100 );

  // Shut down the output stream.
  try {
    dac.closeStream();
  }
  catch ( RtError &error ) {
    error.printMessage();
  }

 cleanup:
  delete data.instrument;

  return 0;
}