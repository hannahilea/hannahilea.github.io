
/***************************************************/
/*! \class Feadog
    \brief STK penny-whistle physical model class
      with 6 toneholes and an optional fipple
      excitation source.

    Hannah Robertson, 2012

    Based on the stk classes BlowHole and Flute
    by Perry R. Cook and Gary P. Scavone, 1995-2011.
                  *************
    Control Change Numbers:
       - Overall gain = 0
       - Whistle type = 1
       - Finger (and breath) speed = 2
       - Openness of lowest hole closed = 3
       - Noise Gain = 5
       - Auto to manual breath speed = 6
       - Change the ratio of jet delay to length = 9
       - Change the articulation envelope = 11
       - Set articulation ADSR attack time = 12
       - Set articulation ADSR decay time = 13
       - Set articulation ADSR gain = 14
       - Excitation source (reed v fipple) = 15
       - Resonance source (tube v tone holes) = 16
       - Clear all delaylines = 100
*/
/***************************************************/


#include "Feadog.h"
#include "SKINI.msg"
#include <cmath>

namespace stk {

//Basic constructor
Feadog :: Feadog( StkFloat whistleType )
{
  whistleType_ = floor( whistleType );
  excitationType_ = 0;
  resonanceType_ = 0;
  StkFloat i[]={0};
  makeWhistle( i ); //Make whistle with default hole locations
}

//Constructor with non-default hole locations
Feadog :: Feadog( StkFloat whistleType, StkFloat whistleArgs[7])
{
  excitationType_ = 0;
  resonanceType_ = 0;
  whistleType_ = floor( whistleType );

  //Not actually setting spacing, setting reed table
  if (whistleArgs[0] == 999 || whistleArgs[0] == 998)
  {
    std::cout << "Using reed table!\n";
    excitationType_ = 1;
  }

  //Not actually setting spacing, setting simple cylindrical body
  if (whistleArgs[0] == 997 || whistleArgs[0] == 998 )
  {
    std::cout << "Using simple cylindrical body\n";
    resonanceType_ = 1;
  }

  //Now actually make the whistle
  if (whistleArgs[0] >= 997)
  {
    StkFloat i[]={0};
    makeWhistle( i );
  }
  else
    makeWhistle( whistleArgs );
}

//Create a whistle given various whistle attributes
void Feadog :: makeWhistle( StkFloat whistleArgs[] )
{
  StkFloat lowestFrequency;   //Frequency of lowest whistle note
  StkFloat rb;                //main bore radius

  //defult radius for each tonehole
  StkFloat rth[] = {0.0025, 0.0025, 0.0025, 0.0015, 0.00215, 0.0025};

  //Set hole spacing: fraction of total delay line between hole and previous
  //hole: air input <--  45% --> hole0 <-- 7% --> hole1 <--.....-->whistle end
  freqs_[0] = .4583;  //between air input and first hole (hole[0])
  freqs_[1] = .0709;
  freqs_[2] = .0634;
  freqs_[3] = .0370;
  freqs_[4] = .0650;
  freqs_[5] = .1185;
  freqs_[6] = .1870; //between last hole and end of whistle


  //CHANGE VARIABLES BASED ON TYPE OF WHISTLE
  switch( whistleType_ ){
    case 1:
      //Low D whistle
      std::cout << "Building low D whistle (low octave).\n";
      lowestFrequency = 298.75; // .5 * intended frequency to get low octave (currently 'overblown' to hit 2nd octave)
      rb = 0.011;
      //Different hole spacing
      freqs_[0] = .4583;
      freqs_[1] = .0709;
      freqs_[2] = .0634;
      freqs_[3] = .0370;
      freqs_[4] = .0650;
      freqs_[5] = .1185;
      freqs_[6] = .1870;
      //Different hole radius values
      rth[0] = 0.005;
      rth[1] = 0.005;
      rth[2] = 0.005;
      rth[3] = 0.003;
      rth[4] = 0.0045;
      rth[5] = 0.005;
      break;
    case 2:
      //Attempting regular pennywhistle
      std::cout << "Attempting a regular high D pennywhistle, high octave (way out of tune!).\n";
      lowestFrequency = 1174.66; //Hz, D6 (actually gives lowest note an octave up)
      rb = 0.0065;
      break;
    default:
      std::cout << "Building a high whistle\n";
      lowestFrequency = 587.33; // Hz, D5 //Actually tuned for low D whistle but plays higher octave
      rb = 0.011;
      freqs_[0] = .4270;
      freqs_[1] = .0481;
      freqs_[2] = .0667;
      freqs_[3] = .0755;
      freqs_[4] = .0356;
      freqs_[5] = .0808;
      freqs_[6] = .2663;
      //Different hole radius values
      rth[0] = 0.005;
      rth[1] = 0.005;
      rth[2] = 0.005;
      rth[3] = 0.003;
      rth[4] = 0.0045;
      rth[5] = 0.005;
      break;
  }

  //Can't build a whistle with 0 length
  if ( lowestFrequency <= 0.0 ) {
    oStream_ << "Feadog::Feadog: argument is less than or equal to zero!";
    handleError( StkError::FUNCTION_ARGUMENT );
  }

  //If there was a special hole spacing passed to this command, make use of it
  if (whistleArgs[0] != 0)
  {
    std::cout << "Specialty hole spacing!\n";
    for (int i = 0; i < 7 ; i++)
      freqs_[i] = whistleArgs[i];
  }

  //Start building the delaylines!
  unsigned long nDelays = (unsigned long) ( 0.5 * Stk::sampleRate() / lowestFrequency );
  nDelay_ = nDelays;

  //For each segment, set delay
  StkFloat delay;
  for ( int i = 0; i < HOLE_COUNT + 1; i++ ){
    delay = (freqs_[i] * nDelays - 1); //Account for 1 sample lastOut delay (for each tonehole and the end filter)

    //Set each delayline segment
    delays_[i].setMaximumDelay( nDelays + 1 );
    delays_[i].setDelay( delay );
  }

  //If this is actually a cylindrical body (no toneholes) reset that first delayline to represent the whole body
  if (resonanceType_ == 1)
    delays_[0].setDelay( nDelays );

  //Initialize the jet delay
  jetDelay_.setMaximumDelay( nDelays + 1);

  //Set reed table (unchanged from stk::BlowHole)
  reedTable_.setOffset( 0.7 );
  reedTable_.setSlope( -0.3 );

  //Set fingers:
  fingerSpeed_ = 0.0001;
  setFingerSpeed();

  //For each tonehole...
  StkFloat te;
  for (int i = 0; i < HOLE_COUNT; i++){
    //Calculate the initial three-port scattering constant for the tonehole
    //given the main bore radius and tonehole radius
    scatter_[i] = -pow(rth[i],2) / ( pow(rth[i],2) + 2*pow(rb,2) );

    //Calculate tonehole's filter coefficients and set hole filter as open.
    te = 1.4 * rth[i];    //effective length of the open hole
    thCoeff_[i] = (te*2*Stk::sampleRate() - 347.23) / (te*2*Stk::sampleRate() + 347.23);
    tonehole_[i].setA1( -thCoeff_[i] );
    tonehole_[i].setB0( thCoeff_[i] );
    tonehole_[i].setB1( -1.0 );

    //Set the finger to be initially up (hole open)
    fingerEnvelopes_[i].setValue( 1 ); //Sets current/goal hole state to open

    //Indicate that until note changes, fingers are fine
    updateFingers_[i] = 0;

    //Indicate that breathing is NOT independent from fingers
    justFingers_ == 0;
  }

  //Set preliminary variables
  volumeGain_ = 1.0;  //Volume of air blown
  noiseGain_ = 0.5;   //Amount of noise

  //Other preliminary variable initializations (unchanged from stk::BlowHole)
  vibrato_.setFrequency((StkFloat) 5.735);
  vibratoGain_ = 0.03;
  outputGain_ = 1;

  //Set prelim variables to do with fipple
  jetDelay_.setMaximumDelay( nDelays + 1 );
  jetEnvelope_.setTarget( 49.0 );
  jetEnvelope_.setTime( fingerSpeed_ ); //envelope rate the same as finger rate

  dcBlock_.setBlockZero();
  adsr_.setAllTimes( 0.005, 0.01, 0.8, 0.010 );
  jetReflection_ = 0.5;
  jetRatio_      = 0.5;

  this->clear();
}

Feadog :: ~Feadog( void )
{
}

void Feadog :: clear( void )
{
  filter_.tick( 0.0 );
  jetDelay_.clear();
  dcBlock_.clear();

  for (int i = 0; i <= HOLE_COUNT; i++)
    delays_[i].clear();
  for (int i = 0; i < HOLE_COUNT; i++)
    tonehole_[i].tick( 0.0 );
}

//In this instrument, frequency is set by the fingering
//rather than the length of the tube. This function is a workaround
//so that (setFrequency) can function for Feadog just as it does for any
//other STK instruments in the various demos and examples.
void Feadog :: setFrequency( StkFloat frequency )
{

#if defined(_STK_DEBUG_)
  if ( frequency <= 0.0 ) {
    oStream_ << "Feadog::setFrequency: argument is less than or equal to zero!";
    handleError( StkError::WARNING ); return;
  }
#endif
  int freq_int_MIDI = (int)frequency;
  getAndFingerNote( freq_int_MIDI );
}

//Set fingering for notes! Single octave, includes half-holes.
void Feadog :: setFingering( int midiNote )
{
    /*62,74 xxxxxx
      64,76 xxxxx
      66,78 xxxx
      67,79 xxx
      69,81 xx
      71,83 x
      73,85
      */

  bool kickup = 0;
  StkFloat thisDelay = 0; //Keep track of new jet delay

  //std::cout << "Excitation type " << excitationType_ << "\n";

  //If notes are in the second octave, set the fingers to octave below
  if ( midiNote > 73)
  {
    kickup = 1;
    midiNote = midiNote - 12;
  }

  switch ( midiNote )
  {
    case 62: //lowest note (standard D)(midi D4)(all closed)
      std::cout << "\tFingering D4.";
      fingerEnvelopes_[0].setTarget( 0 );
      fingerEnvelopes_[1].setTarget( 0 );
      fingerEnvelopes_[2].setTarget( 0 );
      fingerEnvelopes_[3].setTarget( 0 );
      fingerEnvelopes_[4].setTarget( 0 );
      fingerEnvelopes_[5].setTarget( 0 );
      lowestClosedHole_ = 5;
      for (int i = 0; i<7; i++)
        thisDelay += delays_[i].getDelay() + 1;
      break;
    case 63: //(D#/Eb)
      std::cout << "\tFingering D4# (half-holed).";
      fingerEnvelopes_[0].setTarget( 0 );
      fingerEnvelopes_[1].setTarget( 0 );
      fingerEnvelopes_[2].setTarget( 0 );
      fingerEnvelopes_[3].setTarget( 0 );
      fingerEnvelopes_[4].setTarget( 0 );
      fingerEnvelopes_[5].setTarget( .5 );
      lowestClosedHole_ = 5;
      for (int i = 0; i<6; i++)
        thisDelay += delays_[i].getDelay() + 1;
      break;
    case 64: //(standard E)
      std::cout << "\tFingering E.";
      fingerEnvelopes_[0].setTarget( 0 );
      fingerEnvelopes_[1].setTarget( 0 );
      fingerEnvelopes_[2].setTarget( 0 );
      fingerEnvelopes_[3].setTarget( 0 );
      fingerEnvelopes_[4].setTarget( 0 );
      fingerEnvelopes_[5].setTarget( 1 );
      for (int i = 0; i<6; i++)
        thisDelay += delays_[i].getDelay() + 1;
      lowestClosedHole_ = 4;
      break;
    case 65: //(standard F natural)
      std::cout << "\tFingering F natural (half-holed)";
      fingerEnvelopes_[0].setTarget( 0 );
      fingerEnvelopes_[1].setTarget( 0 );
      fingerEnvelopes_[2].setTarget( 0 );
      fingerEnvelopes_[3].setTarget( 0 );
      fingerEnvelopes_[4].setTarget( .5 );
      fingerEnvelopes_[5].setTarget( 1 );
      lowestClosedHole_ = 4;
      for (int i = 0; i<5; i++)
        thisDelay += delays_[i].getDelay() + 1;
      break;
    case 66: //(standard F#)
      std::cout << "\tFingering F#.";
      fingerEnvelopes_[0].setTarget( 0 );
      fingerEnvelopes_[1].setTarget( 0 );
      fingerEnvelopes_[2].setTarget( 0 );
      fingerEnvelopes_[3].setTarget( 0 );
      fingerEnvelopes_[4].setTarget( 1 );
      fingerEnvelopes_[5].setTarget( 1 );
      lowestClosedHole_ = 3;
      for (int i = 0; i<5; i++)
        thisDelay += delays_[i].getDelay() + 1;
      break;
    case 67: //(standard G)
      std::cout << "\tFingering G.";
      fingerEnvelopes_[0].setTarget( 0 );
      fingerEnvelopes_[1].setTarget( 0 );
      fingerEnvelopes_[2].setTarget( 0 );
      fingerEnvelopes_[3].setTarget( 1 );
      fingerEnvelopes_[4].setTarget( 1 );
      fingerEnvelopes_[5].setTarget( 1 );
      lowestClosedHole_ = 2;
      for (int i = 0; i<4; i++)
        thisDelay += delays_[i].getDelay() + 1;
      break;
    case 68: //(standard G#)
      std::cout << "\tFingering G# (half-holed).";
      fingerEnvelopes_[0].setTarget( 0 );
      fingerEnvelopes_[1].setTarget( 0 );
      fingerEnvelopes_[2].setTarget( .5 );
      fingerEnvelopes_[3].setTarget( 1 );
      fingerEnvelopes_[4].setTarget( 1 );
      fingerEnvelopes_[5].setTarget( 1 );
      lowestClosedHole_ = 2;
      for (int i = 0; i<3; i++)
        thisDelay += delays_[i].getDelay() + 1;
      break;
    case 69: //(standard A)
      std::cout << "\tFingering A.";
      fingerEnvelopes_[0].setTarget( 0 );
      fingerEnvelopes_[1].setTarget( 0 );
      fingerEnvelopes_[2].setTarget( 1 );
      fingerEnvelopes_[3].setTarget( 1 );
      fingerEnvelopes_[4].setTarget( 1 );
      fingerEnvelopes_[5].setTarget( 1 );
      lowestClosedHole_ = 1;
      for (int i = 0; i<3; i++)
        thisDelay += delays_[i].getDelay() + 1;
      break;
    case 70: //( A#)
      std::cout << "\tFingering A# (half-holed).";
      fingerEnvelopes_[0].setTarget( 0 );
      fingerEnvelopes_[1].setTarget( .5 );
      fingerEnvelopes_[2].setTarget( 1 );
      fingerEnvelopes_[3].setTarget( 1 );
      fingerEnvelopes_[4].setTarget( 1 );
      fingerEnvelopes_[5].setTarget( 1 );
      lowestClosedHole_ = 1;
      for (int i = 0; i<2; i++)
        thisDelay += delays_[i].getDelay() + 1;
      break;
    case 71: //(standard B)
      std::cout << "\tFingering B.";
      fingerEnvelopes_[0].setTarget( 0 );
      fingerEnvelopes_[1].setTarget( 1 );
      fingerEnvelopes_[2].setTarget( 1 );
      fingerEnvelopes_[3].setTarget( 1 );
      fingerEnvelopes_[4].setTarget( 1 );
      fingerEnvelopes_[5].setTarget( 1 );
      lowestClosedHole_ = 0;
      for (int i = 0; i<2; i++)
        thisDelay += delays_[i].getDelay() + 1;
      break;
    case 72: //(C natural)
      std::cout << "\tFingering C natural (half-holed).";
      fingerEnvelopes_[0].setTarget( 1 );
      fingerEnvelopes_[1].setTarget( 0 );
      fingerEnvelopes_[2].setTarget( 0 );
      fingerEnvelopes_[3].setTarget( 1 );
      fingerEnvelopes_[4].setTarget( 1 );
      fingerEnvelopes_[5].setTarget( 1 );
      lowestClosedHole_ = 0;
      for (int i = 0; i<1; i++)
        thisDelay += delays_[i].getDelay() + 1;
      break;
    case 11: //(alternate C natural)
      std::cout << "\tFingering other C natural (half-holed).";
      fingerEnvelopes_[0].setTarget( .5 );
      fingerEnvelopes_[1].setTarget( 1 );
      fingerEnvelopes_[2].setTarget( 1 );
      fingerEnvelopes_[3].setTarget( 1 );
      fingerEnvelopes_[4].setTarget( 1 );
      fingerEnvelopes_[5].setTarget( 1 );
      lowestClosedHole_ = 0;
      for (int i = 0; i<1; i++)
        thisDelay += delays_[i].getDelay() + 1;
      break;
    default: //73 (c# -- all open)
      std::cout << "\tFingering C# (also default).";
      fingerEnvelopes_[0].setTarget( 1 );
      fingerEnvelopes_[1].setTarget( 1 );
      fingerEnvelopes_[2].setTarget( 1 );
      fingerEnvelopes_[3].setTarget( 1 );
      fingerEnvelopes_[4].setTarget( 1 );
      fingerEnvelopes_[5].setTarget( 1 );
      lowestClosedHole_ = 0;
      thisDelay = delays_[0].getDelay() + 1;
  }
  checkToneholes();

  //Change jet delay (if auto-adjust)
  //If air is automatically adjusted by program, set jet speed
  if ( justFingers_ == 0 )
  {
    if ( kickup == 1 )
    {
      std::cout << " (upper octave)\n";
      thisDelay *= .5; //jump up an octave
    }
    else
      std::cout << "\n";

    //std::cout << "this delay is " << thisDelay << "(nDel is " << nDelay_ << ")\n";

    jetEnvelope_.setTarget( thisDelay * jetRatio_ );
  }
  else
      std::cout << "\n";
}

//Check to see if toneholes are fully shut/open in line with their target state
//(which is set by playing a note)
void Feadog :: checkToneholes( void )
{
  //Check each tonehole individually
  for (int i = 0; i < HOLE_COUNT; i++ ){
    updateFingers_[i] = fingerEnvelopes_[i].getState(); //state is 0 at target, 1 otherwise
  }
}

//Set speed at which holes open/shut
void Feadog :: setFingerSpeed( void )
{
  for (int i = 0; i < HOLE_COUNT; i++ ){
    fingerEnvelopes_[i].setTime( fingerSpeed_ ); //.001 seconds
  }
  //Also set breath speed
  jetEnvelope_.setTime( fingerSpeed_ );
}

//Take both frequency and MIDI note inputs and convert to MIDI number, send to
//setFingering function to actually get played
void Feadog :: getAndFingerNote( StkFloat frequency_or_midi )
{
  int note;
  //If the note played in is in Hz...
  if (frequency_or_midi > 100){
    //Convert freq back to MIDI pitch
    note = 69 + round( 12.0 * log( frequency_or_midi / 440.0 ) / log( 2.0 ));
  }
  else //make sure it's an integer
    {
      note = floor( frequency_or_midi );
    }

  setFingering( note ); //Send the MIDI note value; values outside the
                        //instrument range will be given non-corresponding midi values
}

//Set the tonehole "open-ness" of any specific hole to
//any point between "Open" (newValue = 1) and "Closed"
//(newValue = 0).
void Feadog :: setTonehole( StkFloat newValue, int hole )
{
   //Check hole; if not a legal one, then don't do anything
#if defined(_STK_DEBUG_)
  if (hole >= HOLE_COUNT || hole < 0) {
    oStream_ << "Feadog::tonehole error: hole (" << value << ") doesn't exist on this instrument!";
    handleError( StkError::WARNING ); return;
  }
#endif

  StkFloat new_coeff;

  if ( newValue <= 0.0 )
    new_coeff = 0.9995;
  else if ( newValue >= 1.0 )
    new_coeff = thCoeff_[hole];
  else
    new_coeff = ( newValue * (thCoeff_[hole] - 0.9995) ) + 0.9995;

  //Set the hole to its new number
  tonehole_[hole].setA1( -new_coeff );
  tonehole_[hole].setB0( new_coeff );

}

//Set jet delay based on input ratio (will update on next note)
void Feadog :: setJetDelay( StkFloat aRatio )
{
  if (aRatio <= 0)
  {
    std::cout << "Not adjusting ratio -- less than or equal to zero!\n";
    return;
  }
  jetRatio_ = aRatio;

  // If changing the note won't change the delay line, change the dl now
  if ( justFingers_ == 1 )
    jetEnvelope_.setTarget( nDelay_ * jetRatio_ ); // Scale whole tube by ratio.
}

//Unchanged from stk::BlowHole
void Feadog :: startBlowing( StkFloat amplitude, StkFloat rate )
{
  if ( amplitude <= 0.0 || rate <= 0.0 ) {
    oStream_ << "Feadog::startBlowing: one or more arguments is less than or equal to zero!";
    handleError( StkError::WARNING ); return;
  }
  //Reedtable
  envelope_.setRate( rate );
  envelope_.setTarget( amplitude );

  //Fipple
  adsr_.setAttackRate( rate );
  maxPressure_ = amplitude / (StkFloat) 0.8;
  adsr_.keyOn();
}

//Unchanged from stk::BlowHole
void Feadog :: stopBlowing( StkFloat rate )
{
  if ( rate <= 0.0 ) {
    oStream_ << "Feadog::stopBlowing: argument is less than or equal to zero!";
    handleError( StkError::WARNING ); return;
  }

  envelope_.setRate( rate );
  envelope_.setTarget( 0.0 );

  adsr_.setReleaseRate( rate );
  adsr_.keyOff();
}

//Set the articulation based on type of note
void Feadog :: setArticulation( int articType )
{
  switch ( articType )
  {
    case 1: //tounged attack (sharp staccatto)

      std::cout << "new articulation - sharper\n";
      adsr_.setAttackTime(0.00001);
      adsr_.setDecayTime(.01);
      adsr_.setSustainLevel(.5);
      noiseGain_ = .2;
      break;
    default: //smooth attack (slower build if from 0)
      std::cout << "new articulation - smoother\n";
      adsr_.setAttackTime(1);
      adsr_.setDecayTime(.05);
      adsr_.setSustainLevel(.8); //Sustain level equals attack level
      noiseGain_ = 1;
      break;
  }
}

//Unchanged from stk::BlowHole
void Feadog :: noteOn( StkFloat frequency, StkFloat value )
{
  int freq_int_MIDI = (int)frequency;
  getAndFingerNote( freq_int_MIDI );

  if (justFingers_ == 0) //If not just changing fingers....
  {

    //Default values from BlowHole and Flute classes
    if (excitationType_ == 1) //reedtable
      this->startBlowing( .55 + (value * 0.30), value * 0.005 );
    else //fipple
      this->startBlowing( 1.1 + (value * 0.20), value * 0.02 );
  }
}

//Unchanged from stk::BlowHole
void Feadog :: noteOff( StkFloat amplitude )
{
  this->stopBlowing( amplitude * 0.01 );
}

//SKINI-MIDI controls
void Feadog :: controlChange( int number, StkFloat value )
{
#if defined(_STK_DEBUG_)
  if ( Stk::inRange( value, 0.0, 128.0 ) == false ) {
    oStream_ << "Feadog::controlChange: value (" << value << ") is out of range!";
    handleError( StkError::WARNING ); return;
  }
#endif

  //Change from MIDI 1-128 value to regular value between 1/128 and 1
  StkFloat normalizedValue = value * ONE_OVER_128;

  /*PROGRAM CONTROL NUMBERS*/
  // 0: Scale the output gain from 0 to 1
  if (number == 0)
    outputGain_ = normalizedValue;

  // 1: Change whistle type to a different preset
  else if (number == 1)
  {
    //"set whistle type"
    std::cout << "Just changed whistle to kind " << value << ".\n";
    whistleType_ = floor( value );
    this->clear();
    StkFloat i[]={0};
    this->makeWhistle( i );
  }

  // 15: Change from reed (1) to fipple (0) excitation
  else if (number == 15)
  {
    excitationType_ = value;
    this->clear();
    StkFloat i[]={0};
    this->makeWhistle( i );
  }

  // 16: Change from cylinder (1) to multi-tone (0) resonance
  else if (number == 16)
  {
    resonanceType_ = value;
    this->clear();
    StkFloat i[]={0};
    this->makeWhistle( i );
  }

  // 2: Change the fingering and breath speeds (0 to 1 second)
  else if (number == 2)
  {
    fingerSpeed_ = .0001 + normalizedValue;
    setFingerSpeed(); //includes both finger and breath
    std::cout << "Just changed finger&breath speeds to " << fingerSpeed_ << "\n";
  }

  // 3: Change openness of lowest hole closed
  else if (number == 3)
  {
    this->setTonehole( normalizedValue, lowestClosedHole_ );
    this->checkToneholes();
  }

  // 5: Change noise level (unchanged from stk::BlowHole)
  else if (number == 5)
    noiseGain_ = ( normalizedValue * 0.4);

  // 6: Change from auto-air to self-air (diff notes won't change jet delay)
  else if (number == 6)
    justFingers_ = value ;

  // 9: Manually change the jet delay as ratio of tube length: 0 - 100%
  // Note: if 'auto-air', will affect every note length; if 'self-air' will be
  // ratio compared to full tube
  else if (number == 9)
  {
    std::cout << "Changing to jet delay ratio " << normalizedValue << "\n";
    this->setJetDelay( (StkFloat) ( normalizedValue ) );
  }

  // 11: Make the attack envelope different for different articulations
  else if (number == 11)
  {
    std::cout << "Changing articulation: ";
    /*case 1: Fast tounging (sharp staccatto)
    case 0/default: Slower build*/
    setArticulation( value );
  }

  // 12: Set the breath volume ADSR attack time independently
  else if (number == 12)
  {
    std::cout << "Set ADSR attack to (sec) " << normalizedValue << "\n";
    adsr_.setAttackTime( normalizedValue * 1);
  }

  // 13: Set the breath volume ADSR decay time independently
  else if (number == 13)
  {
    std::cout << "Set ADSRdecay to (sec) " << normalizedValue << "\n";
    adsr_.setDecayTime( normalizedValue * 1);
  }

  // 14: Set the breath volume ADSR gain independently (to btwn .5 and 1)
  else if (number == 14)
  {
    std::cout << "Set ADSR gain to (sec) " << .5 + normalizedValue/2 << "\n";
    volumeGain_ = .5 + normalizedValue/2;
  }

  //Clear the delay lines, rebuild the whistle
  else if (number == 100)
  {
    this->clear();
    StkFloat i[]={0};
    this->makeWhistle( i );
  }
  else
  {
    std::cout << "Sorry, no control change for number " << number;
    std::cout << ", value " << value << ".\n";

#if defined(_STK_DEBUG_)
    oStream_ << "Feadog::controlChange: undefined control number (" << number << ")!";
    handleError( StkError::WARNING );
#endif
  }
}

} //stk namespace
