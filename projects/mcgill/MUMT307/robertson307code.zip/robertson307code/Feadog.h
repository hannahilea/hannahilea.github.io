#ifndef STK_FEADOG_H
#define STK_FEADOG_H

#include "Instrmnt.h"
#include "DelayL.h"
#include "ReedTable.h"
#include "OneZero.h"
#include "PoleZero.h"
#include "Envelope.h"
#include "ADSR.h"
#include "Noise.h"
#include "SineWave.h"
#include "JetTable.h"

namespace stk {

/***************************************************/
/*! \class Feadog
    \brief STK penny-whistle physical model class
      with 6 toneholes and an optional fipple
      excitation source.

    Hannah Robertson, 2012

    Based on the stk classes BlowHole and Flute
    by Perry R. Cook and Gary P. Scavone, 1995-2011.
                  *************
    Control Change Numbers:
       - Overall gain = 0
       - Whistle type = 1
       - Finger (and breath) speed = 2
       - Openness of lowest hole closed = 3
       - Noise Gain = 5
       - Auto to manual breath speed = 6
       - Change the ratio of jet delay to length = 9
       - Change the articulation envelope = 11
       - Set articulation ADSR attack time = 12
       - Set articulation ADSR decay time = 13
       - Set articulation ADSR gain = 14
       - Excitation source (reed v fipple) = 15
       - Resonance source (tube v tone holes) = 16
       - Clear all delaylines = 100
*/
/***************************************************/

const int HOLE_COUNT = 6; //Number of holes in instrument (no fewer than 6!)

class Feadog : public Instrmnt
{
 public:
  //! Class constructor.
  /*!
    An StkError will be thrown if the rawwave path is incorrectly set.
  */
  Feadog( StkFloat whistleType );

  //! Class constructor with additional argument for setting hole locations
  Feadog( StkFloat whistleType, StkFloat whistleArgs[7]);

  //! Class destructor.
  ~Feadog( void );

  //! Reset and clear all internal state.
  void clear( void );

  //! Create the instrument itself
  void makeWhistle( StkFloat whistleArgs[] );

  //! Sets instrument hole states to play a particular frequency (or MIDI #)
  void setFrequency( StkFloat frequency );

  //! Set state of each hole as open or close
  void setFingering( int midiNote );

  //! Check state of all holes to see if they've reached target open/close state
  void checkToneholes( void );

  //! Set speed at which fingers open/close holes, breath between changes
  void setFingerSpeed( void  );

  //! Make sure input note is in midi number range
  void getAndFingerNote( StkFloat frequency_or_midi );

  //! Set the tonehole state for a particular hole(0.0 = closed, 1.0 = open).
  void setTonehole( StkFloat newValue, int hole );

  //! Set the length of the jet delay in terms of a ratio of jet delay to air column delay lengths.
  void setJetDelay( StkFloat aRatio );

  //**TO DO WITH PLAYING NOTES
  //! Apply breath pressure to instrument with given amplitude, rate of increase.
  void startBlowing( StkFloat amplitude, StkFloat rate );

  //! Decrease breath pressure with given rate of decrease.
  void stopBlowing( StkFloat rate );

  //! Start a note with the given frequency and articulation type.
  void noteOn( StkFloat frequency, StkFloat value );

  //! Stop a note with the given speed of decay ("amplitude").
  void noteOff( StkFloat amplitude );

  //! Set the articulation based on type of note
  void setArticulation( int articType );

  //! When inputing breath and fingers independently, ignore all
  //! implied aspects of breath
  void setJustFingers( bool set ) { justFingers_ = set; }

  //**Play-related
  //! Perform the control change specified by \e number and \e value (0.0 - 128.0).
  void controlChange( int number, StkFloat value );

  //! Compute and return one output sample.
  StkFloat tick( unsigned int channel = 0 );

  //! Fill a channel of the StkFrames object with computed outputs.
  /*!
    The \c channel argument must be less than the number of
    channels in the StkFrames argument (the first channel is specified
    by 0).  However, range checking is only performed if _STK_DEBUG_
    is defined during compilation, in which case an out-of-range value
    will trigger an StkError exception.
  */
  StkFrames& tick( StkFrames& frames, unsigned int channel = 0 );


 protected:
  //Specific to type of whistle created:
  int       whistleType_;   // 1 is low D, 0/default is pennywhistle
  bool      excitationType_;  // 1 is reedtable (as in BlowHole), 0 is fipple
  int       resonanceType_;   // 1 is tube w/ no holes, 0 is multi tone holes

  // Whistle body basics
  DelayL    delays_[HOLE_COUNT + 1];  // Segments in pipe (delay lines)
  OneZero   filter_;                  // End reflectance
  StkFloat  nDelay_;                  // Maximum delays of instrument
  StkFloat  freqs_[HOLE_COUNT + 1];   // Ratio distance between each hole on body

  PoleZero  tonehole_[HOLE_COUNT];    // Toneholes (6 in pipe body)
  StkFloat  scatter_[HOLE_COUNT];     // Three-port scattering coefficients, 1 per tonehole
  StkFloat  thCoeff_[HOLE_COUNT];     // Keeps track of filter coefficient for each hole

  // To do with fingers, tonehole states:
  StkFloat  fingerSpeed_;                   // Seconds it takes to open/close tonehole
  Envelope  fingerEnvelopes_[HOLE_COUNT];   // Current state of hole between open/shut
  bool      updateFingers_[HOLE_COUNT];     // "Need to adjust tonehole(s) openness based on new note?"
  bool      updatetemp;
  int       lowestClosedHole_;              // Keeps track of lowest closed hole (for future ornamentation use)

  // **To do with reedtable (holdover from BlowHole):
  ReedTable reedTable_;
  Envelope  envelope_;    //Articulation envelope for reed

  // **To do with fipple
  StkFloat jetRatio_;       //Ratio of jet dl to resonantor dl for lowest open hole
  StkFloat jetReflection_;
  DelayL   jetDelay_;
  Envelope jetEnvelope_; //To keep breath velocity changes smooth (changes w/ finger envelope rate)
  JetTable jetTable_;
  PoleZero dcBlock_;  //Block DC at mouthpiece
  StkFloat maxPressure_;
  ADSR     adsr_;      // ADSR envelope governs breath volume and start/stop

  // **To do with articulation (both reed, fipple):
  bool      justFingers_;     // For noteOn, don't update articulation/breathing
  StkFloat  volumeGain_;      //Scale total output gain up/down as needed
  StkFloat  noiseGain_;   //Additional noise
  Noise     noise_;

  //Hold-over from stk::BlowHole class
  StkFloat  vibratoGain_;
  SineWave  vibrato_;
  StkFloat  outputGain_;
};

//Main tick function
inline StkFloat Feadog :: tick( unsigned int )
{
  //*UPDATE TONEHOLE STATES*//
  // Check and update toneholes if not at target open/shutness be
  updatetemp = 0;
  for (int i = 0; i < HOLE_COUNT; i++ ){
      if ( updateFingers_[i] == 1 ){          // 1 means 'not at target'
        setTonehole( fingerEnvelopes_[i].tick(), i);
        updatetemp = 1;
      }
  }
  if ( updatetemp )
    checkToneholes();

  // Scattering junction variables
  StkFloat pa;    // Input values from (+) direction
  StkFloat pb;    // Input values from (-) direction
  StkFloat pth;   // Last output of current tonehole
  StkFloat temp;  // Scattering junction combo of various input values, scaled

  //*PLAYER AIR INPUT*//
  StkFloat pressureDiff;
  StkFloat breathPressure;

   //*UPDATE Breathing STATE*//
  // Check and update toneholes if not at target open/shutness be
  if ( jetEnvelope_.getState() == 1 )       // 1 means 'not at target'
      jetDelay_.setDelay( jetEnvelope_.tick() );

  //For BlowHole reed table version:
  if (excitationType_ == 1) //reedtable
  {
    // Calculate the breath pressure (envelope + noise + vibrato)
    breathPressure = envelope_.tick();
    breathPressure += breathPressure * noiseGain_ * noise_.tick();
    breathPressure += breathPressure * vibratoGain_ * vibrato_.tick();

    // Calculate the differential pressure = reflected - mouthpiece pressures
    pressureDiff = delays_[0].lastOut() - breathPressure;

    //Initial (player) input into system
    pa = breathPressure + pressureDiff * reedTable_.tick( pressureDiff );
  }
  else //fipple version
  {
    breathPressure =  maxPressure_ * adsr_.tick();
    breathPressure += breathPressure * ( noiseGain_ * noise_.tick() + vibratoGain_ * vibrato_.tick() );

    StkFloat temp = dcBlock_.tick( delays_[0].lastOut() ); // Block DC on reflection.

    pressureDiff = breathPressure - (jetReflection_ * temp);
    pressureDiff = jetDelay_.tick( pressureDiff );

    //Initial (player) input into system
    pa = jetTable_.tick( pressureDiff ) + delays_[0].lastOut(); //get x^3 + x for pressure diff
  }

  //* DELAYLINE UPDATING *//

  //Multi-tone hole body
  if (resonanceType_ != 1)
  {
    //Calculate updated delayline values
    for (int i = 0; i < HOLE_COUNT; i++)
    {
      //Collect current state of each hole
      pb = delays_[i+1].lastOut();
      pth = tonehole_[i].lastOut();
      temp = scatter_[i] * (pa + pb - 2 * pth);

      //Input into tonehole
      tonehole_[i].tick( pa + pb - pth + temp );

      //Input into (-) direction delayline
      delays_[i].tick( pb + temp );

      //Input for the next tonehole filter
      pa += temp;
    }

    //* END REFLECTION FILTER *//
    // Result of end filter gets sent through the last delayline
    delays_[HOLE_COUNT].tick( filter_.tick( pa ) * -0.95 );

    //* PRESSURE OUTPUT *//
    //Take as output the last tick of the first delayline
    lastFrame_[0] = delays_[0].lastOut();
  }

  //otherwise, cylinder
  else
  {
    lastFrame_[0] = (StkFloat) 0.3 * delays_[0].tick( filter_.tick( pa ) *  -.95);
  }

  lastFrame_[0] *= outputGain_;
  return lastFrame_[0];
}

//Un-changed from stk::BlowHole -- allows ticks for multiple channels
inline StkFrames& Feadog :: tick( StkFrames& frames, unsigned int channel )
{
  unsigned int nChannels = lastFrame_.channels();
#if defined(_STK_DEBUG_)
  if ( channel > frames.channels() - nChannels ) {
    oStream_ << "Feadog::tick(): channel and StkFrames arguments are incompatible!";
    handleError( StkError::FUNCTION_ARGUMENT );
  }
#endif

  StkFloat *samples = &frames[channel];
  unsigned int j, hop = frames.channels() - nChannels;
  if ( nChannels == 1 ) {
    for ( unsigned int i=0; i<frames.frames(); i++, samples += hop )
      *samples++ = tick();
  }
  else {
    for ( unsigned int i=0; i<frames.frames(); i++, samples += hop ) {
      *samples++ = tick();
      for ( j=1; j<nChannels; j++ )
        *samples++ = lastFrame_[j];
    }
  }

  return frames;
}

} // stk namespace

#endif
